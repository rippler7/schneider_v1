import React    from "react";
import template from "./cd...jsx";

class cd.. extends React.Component {
  render() {
    return template.call(this);
  }
}

export default cd..;
