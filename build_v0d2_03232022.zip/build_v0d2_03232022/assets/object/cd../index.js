import cd.. from "./cd..";
export default cd..;
